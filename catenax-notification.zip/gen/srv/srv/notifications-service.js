const cds = require('@sap/cds');
const debug = require('debug')('srv:notifications-service');

module.exports = cds.service.impl(async function () {

    const { Notifications } = this.entities;

});